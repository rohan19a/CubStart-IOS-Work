//
//  hw6App.swift
//  hw6
//
//  Created by Andy Huang on 3/8/23.
//

import SwiftUI

@main
struct hw6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
